export class User{
    sno: number | any
    firstName: string | any
    lastName: string | any
    address: string | any
    phoneNumber: number | any
    active: boolean | any
}